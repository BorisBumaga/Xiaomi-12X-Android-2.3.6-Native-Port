# Hardware support — Xiaomi 12X

The screenshots demonstrate Android 2.3.6 system information and the Gingerbread interface. Individual hardware features have not yet been documented as verified.
