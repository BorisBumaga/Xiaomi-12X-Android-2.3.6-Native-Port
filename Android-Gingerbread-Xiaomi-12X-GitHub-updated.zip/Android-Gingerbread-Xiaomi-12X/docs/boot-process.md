# Boot instructions — Xiaomi 12X

The device must have an **unlocked bootloader**. Download the project's compatible `boot.img` release, install Android Platform Tools, boot into fastboot mode, and run:

```bash
fastboot devices
fastboot boot boot.img
```

This command attempts to boot the image in memory **without flashing any partition**. Boot success depends on the supplied image and device configuration.

**At your own risk.** Unlocking the bootloader may wipe data; back up before proceeding. The image is not bundled in this template.
