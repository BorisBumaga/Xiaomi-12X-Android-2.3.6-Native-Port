# Notes

- Experimental Android 2.3.6 build for Xiaomi 12X.
- An unlocked bootloader is required for `fastboot boot boot.img`.
- The verified `boot.img` must be published separately; it is not included in this template.
- Hardware feature support is not fully documented.
