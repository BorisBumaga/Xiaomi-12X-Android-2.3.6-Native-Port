# Build guide

_TODO: Add verified prerequisites, sources/revision IDs, toolchain, commands, patches and resulting checksums._

Do not publish commands as reproducible until tested from a clean checkout.
